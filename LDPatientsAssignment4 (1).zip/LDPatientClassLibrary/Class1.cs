﻿using System;
using System.Text.RegularExpressions;

namespace LDPatientClassLibrary
{
	//New class library
	public class Class1
	{
		
	}
	public static class LDValidations
	{
		//capitalize first character of string and trim spaces
		public static string LDCapitalize(string myString)
		{
			if (myString == null || myString == "")
			{
				return string.Empty;
			}
			else
			{
				myString = myString.ToLower().Trim(' ');
				char[] myChar = myString.ToCharArray();
				myChar[0] = char.ToUpper(myChar[0]);

				return new string(myChar);

			}
		}
		//extract only digits from string
		public static string LDExtractDigits(string aString)
		{
			return Regex.Replace(aString, @"\D", "");
		}
		//validate postal code
		public static string LDPostalCodeValidation(string aString)
		{
			Regex rgx = new Regex(@"^\A[ABCEGHJKLMNPRSTVXY][abceghjklmnprstvxy]\d[A - Z] ?\d[A - Z]\d\z");

			if (aString == "" || aString == string.Empty)
			{
				return aString;
			}
			if (aString != null)
			{
				if (rgx.IsMatch(aString))
				{
					return aString;
				}
				return true.ToString();
			}
			else
			{
				return false.ToString();
			}
		}
		//replace postal code format to add space
		public static string LDPostalCodeFormat(string aString)
		{
			aString = aString + new string(' ', 3);
			return aString;

		}
		//validate american zip code
		public static string LDZipCodeValidation(string aString)
		{
			
			if(aString == null || aString == "")
			{
				aString = string.Empty;
				return true.ToString();
			}
			else
			{
				LDExtractDigits(aString);
				if(aString.Length == 5)
				{
					return aString;
				}
				else if(aString.Length == 9)
				{
					aString = aString + new string('-', 5);
					return aString;
				}
				else
				{
					return false.ToString();
				}
			}
			
			
		}
	}
	
}
