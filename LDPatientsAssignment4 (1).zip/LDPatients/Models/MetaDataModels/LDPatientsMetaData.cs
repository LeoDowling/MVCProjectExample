﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;

namespace LDPatients.Models
{
	[ModelMetadataTypeAttribute(typeof(LDPatientsMetaData))]
	public partial class Patient : IValidatableObject
	{
		// Validate method
		public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
		{
			//if string is not empty, use capitalize method
			if (FirstName != "")
			{
				LDPatientClassLibrary.LDValidations.LDCapitalize(FirstName);
			}
			if (LastName != "")
			{
				LDPatientClassLibrary.LDValidations.LDCapitalize(LastName);
			}
			if (Address != "")
			{
				LDPatientClassLibrary.LDValidations.LDCapitalize(Address);
			}
			if (City != "")
			{
				LDPatientClassLibrary.LDValidations.LDCapitalize(City);
			}
			if (PostalCode != "")
			{
				PostalCode.ToUpper();
				LDPatientClassLibrary.LDValidations.LDCapitalize(PostalCode);
			}
			if (Gender != "")
			{
				LDPatientClassLibrary.LDValidations.LDCapitalize(Gender);
			}
			if(Ohip != "")
			{
				LDPatientClassLibrary.LDValidations.LDCapitalize(Ohip);
			}
			//validation result for postalcode and province
			if (string.IsNullOrEmpty(ProvinceCode))
			{
				yield return new ValidationResult("Province Code is required to validate postal code", new[] { "ProvinceCode", "PostalCode" });
			}
			//validation result for deceased and date of death
			if((Deceased == null && DateOfDeath != null)|| Deceased != null && DateOfDeath == null)
			{
				yield return new ValidationResult("if deceased is true, date of death is required ", new[] {"Deceased","DateOfDeath" });
			}

			yield return ValidationResult.Success;
		}
	}
	public class LDPatientsMetaData
	{
		//Annotations for individual fields
		public int PatientId { get; set; }
		[Display(Name = "First Name")]
		[Required(ErrorMessage = "Must provide a first name")]
		public string FirstName { get; set; }
		[Display(Name = "Last name")]
		[Required(ErrorMessage = "Must Provide a last name")]
		public string LastName { get; set; }
		[Display(Name = "Street Address")]
		public string Address { get; set; }

		public string City { get; set; }
		[Display(Name = "Province Code")]
		[Required(ErrorMessage ="Province Code must be on file")]
		[RegularExpression(@"^[A-Za-z][A-Za-z]$", ErrorMessage = "Province Code must match the code of Xx")]
		public string ProvinceCode { get; set; }
		[Display(Name = "Postal Code")]
		[Required]
		public string PostalCode { get; set; }
		[RegularExpression(@"^\d{4}-\d{3}-\d{3}-[A-Za-z][A-Za-z]$", 
			ErrorMessage = "OHIP, if provided, must match 1234-123-123-XX")]
		[Display(Name = "OHIP")]
		public string Ohip { get; set; }
		[Remote("BirthNotInFuture", "LDPatients",
			 ErrorMessage = "Date of Birth Cannot be in future")]
		public DateTime? DateOfBirth { get; set; }
		public bool Deceased { get; set; }
		public DateTime? DateOfDeath { get; set; }
		[RegularExpression(@"^\d{3}-\d{3}-\d{4}$",
			ErrorMessage = "Phone number, if Provided, must be 10 digits matching 111-111-1111")]
		[StringLength(10)]
		public string HomePhone { get; set; }
		[Remote("Gender", "LDPatients", ErrorMessage = "Gender must be either 'M','F','X'")]
		[Required]
		public string Gender { get; set; }
	}
	
}
