﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using LDPatients.Models;

namespace LDPatients.Controllers
{
    public class LDPatientsController : Controller
    {
        private readonly PatientsContext _context;

        public LDPatientsController(PatientsContext context)
        {
            _context = context;
        }

        // GET: LDPatients
        public async Task<IActionResult> Index()
        {
            var patientsContext = _context.Patient.Include(p => p.ProvinceCodeNavigation).OrderBy(a => a.LastName);
            return View(await patientsContext.ToListAsync());
        }

        // GET: LDPatients/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var patient = await _context.Patient
                .Include(p => p.ProvinceCodeNavigation)
                .FirstOrDefaultAsync(m => m.PatientId == id);
			
            if (patient == null)
            {
                return NotFound();
            }

            return View(patient);
        }

        // GET: LDPatients/Create
        public IActionResult Create()
        {
            ViewData["ProvinceCode"] = new SelectList(_context.Province, "ProvinceCode", "ProvinceCode");
            return View(new Patient());
        }

        // POST: LDPatients/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("PatientId,FirstName,LastName,Address,City,ProvinceCode,PostalCode,Ohip,DateOfBirth,Deceased,DateOfDeath,HomePhone,Gender")] Patient patient, bool Check)
        {
			try
			{
				if (ModelState.IsValid)
				{
					_context.Add(patient);
					await _context.SaveChangesAsync();
					TempData["message"] = "New Patient created";
					return RedirectToAction(nameof(Index));

				}
			}
			catch(Exception ex)
			{
				ModelState.AddModelError("", "Some error occurred, please enter information again");
				ex.GetBaseException();

			}

            ViewData["ProvinceCode"] = new SelectList(_context.Province, "ProvinceCode", "ProvinceCode", patient.ProvinceCode);
            return View(patient);
        }

        // GET: LDPatients/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var patient = await _context.Patient.FindAsync(id);
            if (patient == null)
            {
                return NotFound();
            }
            ViewData["ProvinceCode"] = new SelectList(_context.Province.OrderBy(a => a.ProvinceCode), "ProvinceCode", "ProvinceCode", patient.ProvinceCode);
            return View(patient);
        }

        // POST: LDPatients/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("PatientId,FirstName,LastName,Address,City,ProvinceCode,PostalCode,Ohip,DateOfBirth,Deceased,DateOfDeath,HomePhone,Gender")] Patient patient)
        {
            if (id != patient.PatientId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(patient);
                    await _context.SaveChangesAsync();
					TempData["message"] = "Patient Updated Successfully";
				}
                catch (DbUpdateConcurrencyException)
                {
                    if (!PatientExists(patient.PatientId))
                    {
                        return NotFound();
                    }
                    else
                    {
						ModelState.AddModelError("", "Some error occurred, please enter information again");
					}
                }
                return RedirectToAction(nameof(Index));
            }
			ViewData["ProvinceCode"] = new SelectList(_context.Province.OrderBy(a => a.ProvinceCode), "ProvinceCode", "ProvinceCode", patient.ProvinceCode);
            return View(patient);
        }

        // GET: LDPatients/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var patient = await _context.Patient
                .Include(p => p.ProvinceCodeNavigation)
                .FirstOrDefaultAsync(m => m.PatientId == id);
            if (patient == null)
            {
                return NotFound();
            }

            return View(patient);
        }

        // POST: LDPatients/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
			if(ModelState.IsValid)
			{
				var patient = await _context.Patient.FindAsync(id);
				_context.Patient.Remove(patient);
				await _context.SaveChangesAsync();
				TempData["message"] = "Patient Deleted successfully";
				return RedirectToAction(nameof(Index));
			}
			else
			{
				TempData["message"] = "some error occurred, please try again";
				return RedirectToAction(nameof(Delete));
			}
            
        }

        private bool PatientExists(int id)
        {
            return _context.Patient.Any(e => e.PatientId == id);
        }
		public JsonResult BirthNotInFuture(DateTime birthDate)
		{
			if (birthDate <= DateTime.Now)
				return Json(true);
			else
				return Json("order date cannot be in the future");
		}
		public JsonResult Gender(string gender)
		{
			bool isValid = true;
			if (gender == "M" || gender == "m")
				return Json(isValid);
			else if (gender == "F" || gender == "f")
				return Json(isValid);
			else if (gender == "X" || gender == "x")
				return Json(isValid);
			else if (gender == "" || gender == null)
				return Json("Gender must be either 'M', 'F', or 'X'");
			else
				return Json("Gender must be either 'M', 'F', or 'X'");
		}
		public JsonResult Trim(string trim)
		{
			trim = trim.Trim(' ');
			return Json(trim);
		}
	}
}
